const mongoose = require("mongoose");

const uri = `mongodb://${process.env.DB_PORT || process.env.DB_HOST}:27017/${process.env.DB_NAME}`
// const uri = 'mongodb://127.0.0.1:27017/BDS'
const optionConnectDB = process.env.DB_AUTHENTICATE === "true"
    ?
    {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true,
        useFindAndModify: false,
        user: process.env.DB_USERNAME,
        pass: process.env.DB_PASSWORD
    }
    :
    {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true,
        useFindAndModify: false,
    };


async function initDbConnection() {
    await mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })

        .then(() => {
            console.log("Connect database successfully!");
        })
        .catch(err => {
            console.log('err', err);
        })
    // db.on("error", console.error.bind(console, "MongoDB Connection Error>> : "));
    // db.once("open", function () {
    //     console.log("Connect database successfully!");
    // });

};

module.exports = {
    initDbConnection
};